//
//  AppDelegate.h
//  CS193_1
//
//  Created by Dz Hg on 17/03/2017.
//  Copyright © 2017 Dz Hg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

