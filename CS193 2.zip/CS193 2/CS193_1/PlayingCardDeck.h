//
//  PlayingCardDeck.h
//  CS193_1
//
//  Created by Dz Hg on 19/03/2017.
//  Copyright © 2017 Dz Hg. All rights reserved.
//

#import "Deck.h"
#import "PlayingCard.h"


@interface PlayingCardDeck : Deck




@end
